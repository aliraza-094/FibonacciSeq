public class FibonacciSeq {
	
	private int PrevTerm;     // previous Fibonacci term
	private int CurrTerm;    // Current Fibonacci term
	private int SumEvenTerms;    // Sum of Even Fibonacci terms
	
	FibonacciSeq(){   // Class Constructor Initialize the Perameter
		PrevTerm = 0;
		CurrTerm = 1;
		SumEvenTerms = 0;
	}
	private void PrintFibonacSeq(){    // Generate the Fibonacci terms 
		
		boolean flag = true;		
		
		while(flag){
			CurrTerm = PrevTerm + CurrTerm;
			if(CurrTerm > 4000000){ // loop breaks when CurrTerm value exceeds 4 million
				flag = false;
			}
			else{
				System.out.print(CurrTerm +", ");   // print Fibonacci terms
				if(CurrTerm%2 == 0)     // Check IF Fibonacci terms is even then call function to Add them
				AddEvenTerms(CurrTerm);
				PrevTerm = CurrTerm - PrevTerm;  // Assign last current value to previous 
			}
		}
		System.out.println();
		System.out.println();
	}
	private void AddEvenTerms(int Value){		
		SumEvenTerms += Value;    // Add Even Values of Fibonacci terms 
	}
	private void GetSumEvenTerms(){  // Print Sum of All Even Fibonacci terms
		System.out.print("Sum of Even Fibonacci Terms upto Four Million is: "+ SumEvenTerms);	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		FibonacciSeq FiboObj = new FibonacciSeq();	// Declare Class Object	
		FiboObj.PrintFibonacSeq();      // call funtion to generate Fibonacci Seq
		FiboObj.GetSumEvenTerms();      // call funtion to print Sum of All Even Fibonacci terms
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
